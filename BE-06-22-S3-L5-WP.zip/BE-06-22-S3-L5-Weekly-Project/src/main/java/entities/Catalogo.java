package entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToMany;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "Tipologia")//nome column sul table
public abstract class Catalogo {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id; 
	
	@Column(name = "isbn")
	private int codiceISBN;
	
	private String titolo;
	
	@Column(name = "Anno_Pubblicazione")
	private int annoPub;
	
	@Column(name = "Numero_Pagine")
	private int numPag;
	
    @OneToMany(mappedBy = "prestato")
    private List<Prestito> prestiti;
	
	//getter setter
	public int getCodiceISBN() {
		return codiceISBN;
	}
	public void setCodiceISBN(int codiceISBN) {
		this.codiceISBN = codiceISBN;
	}
	public String getTitolo() {
		return titolo;
	}
	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}
	public int getAnnoPub() {
		return annoPub;
	}
	public void setAnnoPub(int annoPub) {
		this.annoPub = annoPub;
	}
	public int getNumPag() {
		return numPag;
	}
	public void setNumPag(int numPag) {
		this.numPag = numPag;
	}	
}


// /*Creare le classi necessarie a gestire un catalogo bibliotecario. Il catalogo è formato da elementi che possono essere Libri o Riviste. Sia Libri che riviste hanno i seguenti attributi:
//- Codice ISBN (codice univoco)
//- Titolo
//- Anno pubblicazione
//- Numero pagine