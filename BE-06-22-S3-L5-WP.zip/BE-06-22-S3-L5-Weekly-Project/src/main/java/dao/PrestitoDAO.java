package dao;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import entities.Libro;
import entities.Prestito;
import entities.Rivista;
import entities.Utente;
import util.Utility;

public class PrestitoDAO {
	private static final Logger logger = LoggerFactory.getLogger(PrestitoDAO.class);
	
    public static Prestito creaPrestito(Rivista oggetto, Utente ut, LocalDate inizio, LocalDate restituito) {
    	Prestito p = new Prestito();
    	
    	p.setPrestato(oggetto);
    	p.setUtente(ut);
    	p.setpInizio(inizio);
    	p.setpScadenza(inizio.plusDays(30));//30 giorni dopo inizio
    	p.setpRestituito(restituito);
    	
    	return p;
    }
    
    public static Prestito creaPrestito(Libro oggetto, Utente ut, LocalDate inizio, LocalDate restituito) {
    	Prestito p = new Prestito();
    	
    	p.setPrestato(oggetto);
    	p.setUtente(ut);
    	p.setpInizio(inizio);
    	p.setpScadenza(inizio.plusDays(30));
    	p.setpRestituito(restituito);
    	
    	return p;
    }

	public static void salvataggio(Prestito object) {
		EntityManager em = Utility.getEntityManagerFactory().createEntityManager();
		try {
			EntityTransaction t = em.getTransaction();
			t.begin();

			em.persist(object);
			System.out.println("Salvataggio prestito in corso..");
			t.commit();
			attesa(2);
			System.out.println("Salvato con successo!");
		} catch (Exception ex) {
			em.getTransaction().rollback();

			logger.error("Errore nel salvataggio del seguente: " + object.getClass().getSimpleName(), ex);
			throw ex;

		} finally {
			em.close();
		}

	}

	public void refresh(Prestito object) {
		EntityManager em = Utility.getEntityManagerFactory().createEntityManager();
		try {
			em.refresh(object);
			System.out.println("Refresh eseguito!");
		} finally {
			em.close();
		}
	}

	public Prestito getById(Long id) {
		EntityManager em = Utility.getEntityManagerFactory().createEntityManager();
		try {
			System.out.println("Ricerca in corso...");
			attesa(1);
			return em.find(Prestito.class, id);
			
		} finally {
			em.close();
		}

	}

	public void delete(Prestito object) {
		EntityManager em = Utility.getEntityManagerFactory().createEntityManager();
		try {
			System.out.println("Rimozione in corso...");
			EntityTransaction transaction = em.getTransaction();
			transaction.begin();

			em.remove(object);

			transaction.commit();
			attesa(1);
			System.out.println("Rimosso con successo!");
		} catch (Exception ex) {
			em.getTransaction().rollback();
			logger.error("Errore durante l'eleminazione di: " + object.getClass().getSimpleName(), ex);
			throw ex;

		} finally {
			em.close();
		}

	}
	
	public static void attesa(int sec) {
		int millisec = sec * 1000;
		try {
			Thread.sleep(millisec);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
