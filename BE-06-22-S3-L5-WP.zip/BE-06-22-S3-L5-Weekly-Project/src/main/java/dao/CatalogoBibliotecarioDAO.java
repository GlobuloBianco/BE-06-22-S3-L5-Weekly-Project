package dao;

import java.util.List;
import java.util.stream.Stream;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NamedQuery;
import javax.persistence.NoResultException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import entities.Catalogo;
import entities.Libro;
import entities.Rivista;
import enumList.Periodicita;
import util.Utility;

public class CatalogoBibliotecarioDAO {
	private static final Logger logger = LoggerFactory.getLogger(CatalogoBibliotecarioDAO.class);
	
    public static Libro creaLibro(String titolo, int anno, int pagine,String autore, String genere, int ISBN ) {
    	Libro l = new Libro();
    	
    	l.setTitolo(titolo);
    	l.setAnnoPub(anno);
    	l.setNumPag(pagine);
    	l.setAutore(autore);
    	l.setGenere(genere);
    	l.setCodiceISBN(ISBN);
    	
    	return l;
    }
    
    public static Rivista creaRivista(String titolo, int anno, int pagine, Periodicita prd, int ISBN ) {
    	Rivista r = new Rivista();
    	
    	r.setTitolo(titolo);
    	r.setAnnoPub(anno);
    	r.setNumPag(pagine);
    	r.setPeriodicita(prd);
    	r.setCodiceISBN(ISBN);
    	
    	return r;
    }

    public Catalogo getByIsbn(int isbn) {
        EntityManager em = Utility.getEntityManagerFactory().createEntityManager();
        try {
            System.out.println("Ricerca in corso...");
            attesa(1);
            return em.createQuery("SELECT e FROM Catalogo e WHERE e.codiceISBN = :isbn", Catalogo.class)
                .setParameter("isbn", isbn)
                .getSingleResult();
        } catch (NoResultException nre) {
            System.out.println("Nessun elemento trovato con ISBN: " + isbn);
            return null;
        } finally {
            em.close();
        }
    }
    
    public List<Catalogo> getByAnnoPub(int anno) {
        EntityManager em = Utility.getEntityManagerFactory().createEntityManager();
        try {
            System.out.println("Ricerca in corso...");
            attesa(1);
            return em.createQuery("SELECT e FROM Catalogo e WHERE e.annoPub = :annoPub", Catalogo.class)
                .setParameter("annoPub", anno)
                .getResultList();
        } catch (NoResultException nre) {
            System.out.println("Nessun elemento trovato con anno: " + anno);
            return null;
        } finally {
            em.close();
        }
    }
    
    public List<Libro> getByAutore(String autore) {
        EntityManager em = Utility.getEntityManagerFactory().createEntityManager();
        try {
            System.out.println("Ricerca in corso...");
            attesa(1);
            return em.createQuery("SELECT e FROM Libro e WHERE e.autore = :autore", Libro.class)
                .setParameter("autore", autore)
                .getResultList();
        } catch (NoResultException nre) {
            System.out.println("Nessun elemento trovato con autore: " + autore);
            return null;
        } finally {
            em.close();
        }
    }
    
    public Catalogo getByTitolo(String titolo) {
        EntityManager em = Utility.getEntityManagerFactory().createEntityManager();
        try {
            System.out.println("Ricerca in corso...");
            attesa(1);
            return em.createQuery("SELECT e FROM Catalogo e WHERE e.titolo = :titolo", Catalogo.class)
                .setParameter("titolo", titolo)
                .getSingleResult();
        } catch (NoResultException nre) {
            System.out.println("Nessun elemento trovato con Titolo: " + titolo);
            return null;
        } finally {
            em.close();
        }
    }
    
	public static void salvataggio(Catalogo object) {
		EntityManager em = Utility.getEntityManagerFactory().createEntityManager();
		try {
			EntityTransaction t = em.getTransaction();
			t.begin();

			em.persist(object);
			System.out.println("Salvataggio in corso..");
			t.commit();
			attesa(2);
			System.out.println("Salvato con successo!");
		} catch (Exception ex) {
			em.getTransaction().rollback();

			logger.error("Errore nel salvataggio del seguente: " + object.getClass().getSimpleName(), ex);
			throw ex;

		} finally {
			em.close();
		}

	}

	public void refresh(Catalogo object) {
		EntityManager em = Utility.getEntityManagerFactory().createEntityManager();
		try {
			em.refresh(object);
			System.out.println("Refresh eseguito!");
		} finally {
			em.close();
		}
	}

	public Catalogo getById(Long id) {
		EntityManager em = Utility.getEntityManagerFactory().createEntityManager();
		try {
			System.out.println("Ricerca in corso...");
			attesa(1);
			return em.find(Catalogo.class, id);
			
		} finally {
			em.close();
		}

	}

	public void delete(Catalogo object) {
		EntityManager em = Utility.getEntityManagerFactory().createEntityManager();
		try {
			System.out.println("Rimozione in corso...");
			EntityTransaction transaction = em.getTransaction();
			transaction.begin();
			
			em.remove(object);

			transaction.commit();
			attesa(1);
			System.out.println("Rimosso con successo!");
		} catch (Exception ex) {
			em.getTransaction().rollback();
			logger.error("Errore durante l'eleminazione di: " + object.getClass().getSimpleName(), ex);
			throw ex;

		} finally {
			em.close();
		}

	}
	
	public static void attesa(int sec) {
		int millisec = sec * 1000;
		try {
			Thread.sleep(millisec);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
