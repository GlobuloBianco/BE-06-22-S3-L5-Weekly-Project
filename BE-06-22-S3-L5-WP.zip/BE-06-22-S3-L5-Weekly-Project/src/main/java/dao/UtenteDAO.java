package dao;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import entities.Utente;
import util.Utility;

public class UtenteDAO {
	private static final Logger logger = LoggerFactory.getLogger(UtenteDAO.class);
	
    public static Utente creaUtente(String nome, String cognome, LocalDate nascita, String tessera ) {
    	Utente u = new Utente();
    	
    	u.setNome(nome);
    	u.setCognome(cognome);
    	u.setDataNascita(nascita);
    	u.setTessera(tessera);
    	
    	return u;
    }

	public static void salvataggio(Utente object) {
		EntityManager em = Utility.getEntityManagerFactory().createEntityManager();
		try {
			EntityTransaction t = em.getTransaction();
			t.begin();

			em.persist(object);
			System.out.println("Salvataggio utente in corso..");
			t.commit();
			attesa(2);
			System.out.println("Salvato con successo!");
		} catch (Exception ex) {
			em.getTransaction().rollback();

			logger.error("Errore nel salvataggio del seguente: " + object.getClass().getSimpleName(), ex);
			throw ex;

		} finally {
			em.close();
		}

	}

	public void refresh(Utente object) {
		EntityManager em = Utility.getEntityManagerFactory().createEntityManager();
		try {
			em.refresh(object);
			System.out.println("Refresh eseguito!");
		} finally {
			em.close();
		}
	}

	public Utente getById(int id) {
		EntityManager em = Utility.getEntityManagerFactory().createEntityManager();
		try {
			System.out.println("Ricerca in corso...");
			attesa(1);
			return em.find(Utente.class, id);
			
		} finally {
			em.close();
		}

	}

	public void delete(Utente object) {
		EntityManager em = Utility.getEntityManagerFactory().createEntityManager();
		try {
			System.out.println("Rimozione in corso...");
			EntityTransaction transaction = em.getTransaction();
			transaction.begin();

			em.remove(object);

			transaction.commit();
			attesa(1);
			System.out.println("Rimosso con successo!");
		} catch (Exception ex) {
			em.getTransaction().rollback();
			logger.error("Errore durante l'eleminazione di: " + object.getClass().getSimpleName(), ex);
			throw ex;

		} finally {
			em.close();
		}

	}
	
	public static void attesa(int sec) {
		int millisec = sec * 1000;
		try {
			Thread.sleep(millisec);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
