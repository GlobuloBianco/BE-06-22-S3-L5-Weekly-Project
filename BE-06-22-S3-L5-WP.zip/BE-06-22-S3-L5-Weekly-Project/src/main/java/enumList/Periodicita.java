package enumList;

public enum Periodicita {
	SETTIMANALE, MENSILE, SEMESTRALE
}
