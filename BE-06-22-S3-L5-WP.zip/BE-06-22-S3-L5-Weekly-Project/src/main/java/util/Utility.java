package util;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Utility {
	
	private static final Logger logger = LoggerFactory.getLogger(Utility.class);
	private static final EntityManagerFactory entityManagerFactory;

	static {
		try {
			entityManagerFactory = Persistence
					.createEntityManagerFactory("BE-06-22-S3-L5-Weekly-Project");
		} catch (Throwable ex) {
			logger.error("Inizializzazione della creazione EntityManagerFactory fallita! >:(.", ex);
			throw new ExceptionInInitializerError(ex);
		}
	}

	public static EntityManagerFactory getEntityManagerFactory() {
		return entityManagerFactory;
	}
}
