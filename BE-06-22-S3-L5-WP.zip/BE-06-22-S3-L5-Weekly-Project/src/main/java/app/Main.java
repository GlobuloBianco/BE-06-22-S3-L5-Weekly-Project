package app;

import entities.Libro;
import entities.Prestito;
import entities.Rivista;
import entities.Utente;
import enumList.Periodicita;

import java.time.LocalDate;

import dao.CatalogoBibliotecarioDAO;
import dao.PrestitoDAO;
import dao.UtenteDAO;

public class Main {
	static UtenteDAO uDao = new UtenteDAO();
	static PrestitoDAO pDao = new PrestitoDAO();
	static CatalogoBibliotecarioDAO cDao = new CatalogoBibliotecarioDAO();

	public static void main(String[] args) {
		//Crea();
		//cDao.getByIsbn(14393);
		//cDao.getByAnnoPub(2022);
		//cDao.getByAutore("Dante Alighieri");
		//cDao.getByTitolo("National Geographic");
	}

	
	
	// ----------methods----------//
	@SuppressWarnings("static-access")
	public static void Crea() {
		// riviste
		Rivista r1 = cDao.creaRivista("Vogue", 2022, 200, Periodicita.MENSILE, 14393);
		Rivista r2 = cDao.creaRivista("National Geographic", 2022, 150, Periodicita.MENSILE, 14394);
		Rivista r3 = cDao.creaRivista("Cosmopolitan", 2021, 100, Periodicita.SEMESTRALE, 14395);
		cDao.salvataggio(r1);
		cDao.salvataggio(r2);
		cDao.salvataggio(r3);
		// libri
		Libro l1 = cDao.creaLibro("Il Signore degli Anelli", 2022, 500, "J.R.R. Tolkien", "Fantasy", 41252);
		Libro l2 = cDao.creaLibro("Harry Potter e la Pietra Filosofale", 2022, 400, "J.K. Rowling", "Fantasy", 41253);
		Libro l3 = cDao.creaLibro("La Divina Commedia", 2022, 600, "Dante Alighieri", "Narrativa", 41254);
		cDao.salvataggio(l1);
		cDao.salvataggio(l2);
		cDao.salvataggio(l3);
		// utenti
		Utente u1 = uDao.creaUtente("Mario", "Rossi", LocalDate.of(1999, 8, 1), "S4LGK14L");
		Utente u2 = uDao.creaUtente("Lucia", "Bianchi", LocalDate.of(2000, 5, 12), "S4LGK15L");
		Utente u3 = uDao.creaUtente("Giovanni", "Neri", LocalDate.of(1998, 3, 3), "S4LGK16L");
		uDao.salvataggio(u1);
		uDao.salvataggio(u2);
		uDao.salvataggio(u3);
		// prestito
		Prestito p1 = pDao.creaPrestito(r1, u2, LocalDate.of(2023, 1, 13), LocalDate.of(2023, 2, 15));
		Prestito p2 = pDao.creaPrestito(r3, u1, LocalDate.of(2023, 3, 15), LocalDate.of(2023, 3, 28));
		Prestito p3 = pDao.creaPrestito(l1, u3, LocalDate.of(2023, 5, 21), LocalDate.of(2023, 6, 25));
		pDao.salvataggio(p1);
		pDao.salvataggio(p2);
		pDao.salvataggio(p3);
	}

}

/*
 * Creare le classi necessarie a gestire un catalogo bibliotecario. Il catalogo
 * è formato da elementi che possono essere Libri o Riviste. Sia Libri che
 * riviste hanno i seguenti attributi: - Codice ISBN (codice univoco) - Titolo -
 * Anno pubblicazione - Numero pagine
 * 
 * I libri hanno inoltre: - Autore - Genere
 * 
 * Le riviste hanno: - Periodicità [SETTIMANALE, MENSILE, SEMESTRALE]
 * -----------------------------------------------------------------------------
 * --- Creare inoltre le classi necessarie alla gestione del prestito:
 * 
 * L'utente è caratterizzato dai seguenti attributi: - Nome - Cognome - Data di
 * nascita - Numero di tessera
 * 
 * Il prestito è caratterizzato da: - Utente - Elemento prestato (può essere un
 * libro o una rivista) - Data inizio prestito - Data restituzione prevista
 * (calcolata automaticamente a 30 gg dalla data inizio prestito) - Data
 * restituzione effettiva
 * 
 * -----------------------------------------------------------------------------
 * L'archivio deve permettere le seguenti operazioni:
- Aggiunta di un elemento del catalogo--------------
- Rimozione di un elemento del catalogo dato un codice ISBN
- Ricerca per ISBN
- Ricerca per anno pubblicazione
- Ricerca per autore
- Ricerca per titolo o parte di esso
- Ricerca degli elementi attualmente in prestito dato un numero di tessera utente
- Ricerca di tutti i prestiti scaduti e non ancora restituiti
 */